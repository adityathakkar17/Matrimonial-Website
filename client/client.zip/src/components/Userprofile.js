import React, { useEffect, useState } from "react";
import { useHistory } from "react-router";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../index.css';
import userpic from '../image_profiles/user.jpeg';
import { Link } from "react-router-dom";
const Userprofile = () => {
    const history = useHistory();
    const [userData, setUserData] = useState({});
    const [imagePath, setPath] = useState('');
    const calluserprofile = async () => {
        try {
            const res = await fetch("/about", {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                credentials: "include"

            });
            const data = await res.json();

            if (!res.status === 200) {
                const error = new Error(res.error);
                throw error;
            }
            else {
                setUserData(data);
                setPath("http://localhost:5000/public/userProfiles/")
            }
        }
        catch (err) {
            console.log(err);
            history.push("/Login");
        }
    }
    useEffect(() => {
        calluserprofile();
    }, []);

    return (
        <>
            <div className="container emp-profile">
                <form method="post">
                    <div className="row">
                        <div className="col-md-3">
                            <div className="profile-img">
                                <img src={userData.profile ? imagePath + userData.profile : userpic} width="150px" alt="" />
                                {/* <div className="file btn btn-lg btn-primary">
                                Change Photo
                                <input type="file" name="file"/>
                            </div> */}
                            </div>
                        </div>
                        <div className="col">
                            <div className="profile-head">
                                <h5>
                                    {userData.name}
                                </h5>
                                <h6>
                                    Web Developer and Designer
                                </h6>

                                <ul className="nav nav-tabs" id="myTab" role="tablist">
                                    <li className="nav-item">
                                        <a className="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    
                    <div className="row">
                        <div className="col-md-4">

                        </div>
                        <div className="col">
                            <div className="profile-head">
                            <div className="tab-content profile-tab" id="myTabContent">
                                <div className="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                    <div className="row">
                                        <div className="col">
                                            <h5>User ID</h5>
                                        </div>
                                        <div className="col">
                                            <p>{userData._id}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Name</h5>
                                        </div>
                                        <div className="col">
                                            <p>{userData.name}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Email</h5>
                                        </div>
                                        <div className="col">
                                            <p>{userData.email}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Phone Number</h5>
                                        </div>
                                        <div className="col">
                                            <p>{userData.phone}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Age</h5>
                                        </div>
                                        <div className="col">
                                            <p>{userData.age}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Date of Birth</h5>
                                        </div>
                                        <div className="col">
                                            <p>{userData.dob}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Gender</h5>
                                        </div>
                                        <div className="col">
                                            <p>{userData.gender}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Marital Status</h5>
                                        </div>
                                       
                                        <div className="col">
                                            <p>{userData.marital_status}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Mother Tongue</h5>
                                        </div>
                                        
                                        <div className="col">
                                            <p>{userData.mother_tongue}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Religion</h5>
                                        </div>
                                       
                                        <div className="col">
                                            <p>{userData.religion}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>City</h5>
                                        </div>
                                       
                                        <div className="col">
                                            <p>{userData.city}</p>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <h5>Pincode</h5>
                                        </div>
                                        
                                        <div className="col">
                                            <p>{userData.pincode}</p>
                                        </div>
                                    </div>
                                </div>
                                <hr/>
                               </div>
                        <Link to={`/Search/`}><button className="btn btn-primary btn-lg btn-block">Back</button></Link>
                                &emsp;
                            <Link to={`/editprofile`}><button className="btn btn-success btn-lg btn-block">Edit Profile</button></Link>

                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </>
    )
}

export default Userprofile;