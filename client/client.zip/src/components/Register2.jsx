import { render } from "@testing-library/react";
import React, { useState } from "react";

// import { useState } from "react-router-dom";


const Register = () => {
    const [details, setdetails] = useState({
        username: "",
        email: "",
        password: "",
        dob: "",
        marital_status: "",
        mother_tongue: "",
        religion: "",
        city: "",
        pincode: "",
        phoneno: "",
    });

    const [errors, setErrors] = useState({
        usernameError: "",
        emailError: "",
        passwordError: "",
        dobError: "",
        marital_statusError: "",
        mother_tongueError: "",
        religionError: "",
        cityError: "",
        pincodeError: "",
        phonenoError: "",
    })


    const details_input = (event) => {
        const { value, name } = event.target;
        setdetails((preValue) => {
            if (name === "username") {
                return {
                    username: value,
                    email: preValue.email,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "email") {
                return {
                    username: preValue.username,
                    email: value,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "password") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: value,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "date") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: preValue.password,
                    dob: value,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "maritial") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: value,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "mother_tongue") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: value,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "religion") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: value,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "city") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: value,
                    pincode: preValue.pincode,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "pincode") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: value,
                    phoneno: preValue.phoneno,
                }
            }
            else if (name === "phoneno") {
                return {
                    username: preValue.username,
                    email: preValue.email,
                    password: preValue.password,
                    dob: preValue.dob,
                    marital_status: preValue.marital_status,
                    mother_tongue: preValue.mother_tongue,
                    religion: preValue.religion,
                    city: preValue.city,
                    pincode: preValue.pincode,
                    phoneno: value,
                }
            }
        })
    }

    const onsubmit = (event) => {
        event.preventDefault();

        const {name,age,dob,gender,phone,email,password}= user;

        const res = await fetch("/register",{
            method:"POST",
            headers:{
                "Contebt-Type":"application/json"
            },
            body:JSON.stringify({
                name,age,dob,gender,phone,email,password
            })
        });
        const data = await res.json();
        if(data.status===422 || !data){
            window.alert("Registration unsuccessful");
        }else{
            window.alert("Registration successful");
        }
        // alert(details.username + details.email + details.dob + details.marital_status + details.mother_tongue);
        let errors = {}
        if (!details.username.trim()) {
            errors.username = "Username required";
        }
        if (!details.email) {
            errors.email = "email required";
        } else if (!/\S+@\S+\.\S+/.test(details.email)) {
            errors.email = 'Email address is invalid';
        }
        if (!details.password.trim()) {
            errors.password = "Password is required";
        }
        if (!details.dob) {
            errors.dobError = "Date Of Birth is required";
        }
        if (!details.marital_status) {
            errors.marital_statusError = "Marital Status Cannot be empty";
        }
        if (!details.mother_tongue) {
            errors.mother_tongueError = "Mother Tongue Cannot be empty";
        }
        if (!details.religion) {
            errors.religionError = "Religion cannot be empty";
        }
        if (!details.city) {
            errors.cityError = "City need to be selected";
        }
        if (!details.pincode) {
            errors.pincodeError = "Pincode is empty";
        }
        else if (details.pincode.length !== 6) {
            errors.pincodeError = "Pincode must have exactly 6 digits";
        } else if (isNaN(details.pincode)) {
            errors.pincodeError = "Pincode must be a valid number";
        }
        if (!details.phoneno) {
            errors.phonenoError = "Phone number is empty";
        } else if (details.phoneno.length !== 10) {
            errors.phonenoError = "Phone number must have exactly 10 digits";
        } else if (isNaN(details.phoneno)) {
            errors.phonenoError = "Phone number must b a valid number";
        }

        setErrors((preValue) => {
            return {
                usernameError: errors.username,
                emailError: errors.email,
                passwordError: errors.password,
                dobError: errors.dobError,
                marital_statusError: errors.marital_statusError,
                mother_tongueError: errors.mother_tongueError,
                religionError: errors.religionError,
                cityError: errors.cityError,
                pincodeError: errors.pincodeError,
                phonenoError: errors.phonenoError
            }
        })
    };


    return (
        <>
            <form onSubmit={onsubmit}>
                <div>
                    <div>
                        <label>Name :</label>
                        <input type="text" placeholder="Enter Your Name" name="username" onChange={details_input} value={details.username} />
                    </div>
                    {errors.usernameError && <p>{errors.usernameError}</p>}
                    <br />
                    <div>
                        <label>Email :</label>
                        <input type="text" placeholder="Enter Your Email" name="email" onChange={details_input} value={details.email} />
                    </div>
                    {errors.emailError && <p>{errors.emailError}</p>}
                    <br />
                    <div>
                        <label>Password :</label>
                        <input type="password" placeholder="enter Your Password" name="password" onChange={details_input} value={details.password} />
                    </div>
                    <br />
                    {errors.passwordError && <p>{errors.passwordError}</p>}
                    <div>
                        <label>Date of Birth :</label>
                        <input type="date" onChange={details_input} name="date" value={details.dob} />
                    </div>
                    <br />
                    {errors.dobError && <p>{errors.dobError}</p>}
                    <div>
                        <label>Marital Status :</label>
                        <select name="maritial" onChange={details_input} required value={details.marital_status} >
                            <option value selected="selected">Please Select</option>
                            <option value="Never Married">Never Married</option>
                            <option value="Married">Married</option>
                            <option value="Awaiting Divorce">Awaiting Divorce</option>
                            <option value="Divorced">Divorced</option>
                            <option value="Widowed">Widowed</option>
                            <option value="Annulled">Annulled</option>
                        </select>
                    </div>
                    {errors.marital_statusError && <p>{errors.marital_statusError}</p>}
                    <br />
                    <div>
                        <label>Mother Tongue</label>
                        <select name="mother_tongue" onChange={details_input} value={details.mother_tongue}>
                            <option value="" selected="selected">Please Select</option>
                            <optgroup label="&nbsp;"></optgroup>
                            <optgroup label="North">
                                <option value="Hindi/ Delhi">Hindi/ Delhi</option>
                                <option value="Hindi /Madhya Pradesh / Bundelkhand / Chattisgarhi">Hindi /Madhya Pradesh / Bundelkhand / Chattisgarhi</option>
                                <option value="Hindi/U.P./Awadhi/ Bhojpuri/Garhwali">Hindi/U.P./Awadhi/ Bhojpuri/Garhwali</option>
                                <option value="Punjabi">Punjabi</option>
                                <option value="Bihari/Maithili/Magahi">Bihari/Maithili/Magahi</option>
                                <option value="Rajasthani / Marwari / Malwi / Jaipuri">Rajasthani / Marwari / Malwi / Jaipuri</option>
                                <option value="Haryanvi">Haryanvi</option>
                                <option value="Himachali/Pahari">Himachali/Pahari</option>
                                <option value="Kashmiri/Dogri">Kashmiri/Dogri</option>
                                <option value="Sindhi">Sindhi</option>
                                <option value="Urdu">Urdu</option></optgroup>
                            <optgroup label="&nbsp;&nbsp;"></optgroup>
                            <optgroup label="West">
                                <option value="Marathi">Marathi</option>
                                <option value="Gujarati">Gujarati</option>
                                <option value="Kutchi">Kutchi</option>
                                <option value="Hindi /Madhya Pradesh / Bundelkhand / Chattisgarhi">Hindi /Madhya Pradesh / Bundelkhand / Chattisgarhi</option>
                                <option value="Konkani">Konkani</option>
                                <option value="Sindhi">Sindhi</option></optgroup>
                            <optgroup label="&nbsp;&nbsp;&nbsp;"></optgroup>
                            <optgroup label="South">
                                <option value="Tamil">Tamil</option>
                                <option value="Telugu">Telugu</option>
                                <option value="Kannada">Kannada</option>
                                <option value="Malayalam">Malayalam</option>
                                <option value="Tulu">Tulu</option>
                                <option value="Urdu">Urdu</option></optgroup>
                            <optgroup label="&nbsp;&nbsp;&nbsp;&nbsp;"></optgroup>
                            <optgroup label="East">
                                <option value="Bengali">Bengali</option>
                                <option value="Oriya">Oriya</option>
                                <option value="Assamese">Assamese</option>
                                <option value="Sikkim/ Nepali/ Lepcha/ Bhutia/ Limbu">Sikkim/ Nepali/ Lepcha/ Bhutia/ Limbu</option></optgroup>
                            <optgroup label="---------"><option value="English">English</option></optgroup>
                        </select>
                    </div>
                    {errors.mother_tongueError && <p>{errors.mother_tongueError}</p>}
                    <br />
                    <div>
                        <label>Religion :</label>
                        <select name="religion" onChange={details_input} value={details.religion}>
                            <option value="" selected="selected">Select a Religion</option>
                            <option value="Hindu">Hindu</option>
                            <option value="Muslim">Muslim</option>
                            <option value="Sikh">Sikh</option>
                            <option value="Christian">Christian</option>
                            <option value="Buddhist">Buddhist</option>
                            <option value="Jain">Jain</option>
                            <option value="Parsi">Parsi</option>
                            <option value="Jewish">Jewish</option>
                            <option value="Bahai">Bahai</option>
                        </select>
                    </div>
                    {errors.religionError && <p>{errors.religionError}</p>}
                    <br />
                    <div>
                        <label>City :</label>
                        <select name="city" onChange={details_input} value={details.city}>
                            <optgroup label=" "><option value="New Delhi">New Delhi</option>
                                <option value="Mumbai">Mumbai</option>
                                <option value="Bangalore">Bangalore</option>
                                <option value="Hyderabad/Secunderabad">Hyderabad/Secunderabad</option>
                                <option value="Pune/ Chinchwad">Pune/ Chinchwad</option>
                                <option value="Chennai/ Madras">Chennai/ Madras</option>
                                <option value="Kolkata">Kolkata</option>
                                <option value="Ahmedabad">Ahmedabad</option>
                            </optgroup>
                        </select>
                    </div>
                    {errors.cityError && <p>{errors.cityError}</p>}
                    <br />
                    <div>
                        <label>Pincode :</label>
                        <input type="text" name="pincode" onChange={details_input} value={details.pincode} ></input>
                    </div>
                    {errors.pincodeError && <p>{errors.pincodeError}</p>}
                    <br />
                    <div>
                        <label>Mobile Number :</label>
                        <input type="text" maxLength="10" name="phoneno" onChange={details_input} value={details.phoneno}></input>
                    </div>
                    {errors.phonenoError && <p>{errors.phonenoError}</p>}
                    <div>
                        <button id="loginbutton">Submit</button>
                    </div>

                </div>
            </form>

        </>
    );


}

export default Register;