import React, { useContext, useState } from "react";
import { Link, useHistory } from "react-router-dom";
import { UserContext } from "../App";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const Login = () => {
    const { state, dispatch } = useContext(UserContext);
    const history = useHistory();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const loginUser = async (e) => {
        e.preventDefault();
        if (!password) {
            toast.error("Password is required", { position: toast.POSITION.TOP_CENTER });
        }
        if (!email) {
            toast.error("Email is required", { position: toast.POSITION.TOP_CENTER });
        }
        else {
            const res = await fetch("/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email,
                    password
                })
            });
            const data = await res.json();
            if (res.status === 422 || !data) {
                window.alert(data.error);
            }
            else {
                dispatch({ type: "USER", payload: true })
                toast.success("Login successful", { position: toast.POSITION.TOP_CENTER });
                // window.alert(data.message);
                history.push("/editprofile");
            }
        }

        // alert(email + password);
    }
    return (
        <>
        <br /><br /><br />
            <section class="sign-in">
                <div class="container">
                    <div class="signin-content">
                        {/* <div class="signin-image">
                        <figure><img src="../Login/login/images/signin-image.jpg" alt="sing up image" /></figure>
                        <a href="#" class="signup-image-link">Create an account</a>
                    </div> */}

                        <div class="signin-form">
                            <h2 class="form-title">Log In</h2>
                            <form method="POST" class="register-form" id="login-form">
                                <div class="form-group">
                                    <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                    <input type="email" name="your_name" id="your_name" placeholder="Your Name" onChange={(e) => setEmail(e.target.value)} value={email} />
                                </div>
                                <div class="form-group">
                                    <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                    <input type="password" onChange={(e) => setPassword(e.target.value)} value={password} name="your_pass" id="your_pass" placeholder="Password" />
                                </div>
                                {/* <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div> */}
                                <div class="form-group form-button">
                                    <input type="submit" name="signin" id="signin" class="form-submit" onClick={loginUser} value="Log in" />
                                </div>
                                <Link to="/Register">New User?</Link>
                            </form>
                            {/* <div class="social-login">
                            <span class="social-label">Or login with</span>
                            <ul class="socials">
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-facebook"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-twitter"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-google"></i></a></li>
                            </ul>
                        </div> */}
                        </div>
                    </div>
                </div>
            </section>
            {/* <form method="POST">
                <div className="container">
                    <div className="login">
                        <h2 className="loginheader">Email</h2>
                        <input className="logininput" name="email" type="text" placeholder="Enter Your Name" onChange={(e) => setEmail(e.target.value)} value={email} required />
                        <br />
                        <h2 className="loginheader">Password</h2>
                        <input className="logininput" type="password" placeholder="Enter Your Password" name="password" onChange={(e) => setPassword(e.target.value)} value={password} required />
                        <button id="loginbutton" onClick={loginUser}>Submit</button>
                        <br />
                        <Link to="/Register">New User?</Link>
                    </div>

                </div>
            </form> */}
        </>
    );
}

export default Login;